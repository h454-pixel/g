package com.example.practice_1;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface Myapi {


 @GET
 //("top-headlines?country=us&category=business&apiKey=49c3c9be3cda4ebf986c1215fa83da55")

         ("top-headlines")
 Call<NewsModel> getNews(@Query("country") String country1, @Query("category")String category1,
                         @Query("apiKey") String key );



}
